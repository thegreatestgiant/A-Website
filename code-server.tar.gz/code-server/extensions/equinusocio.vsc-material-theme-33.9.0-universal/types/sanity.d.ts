declare module '@sanity/client';
