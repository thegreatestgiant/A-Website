# Publish to open-vsx&#46;org

To publish this extension to the [Open VSX Registry](https://open-vsx.org/), run:

```console
npx ovsx publish .\five-server-x.x.x.vsix -p TOKEN
```
