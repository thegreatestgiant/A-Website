# npm install @vscode/test-web
npx vscode-test-web --browserType=chromium --extensionDevelopmentPath=.
